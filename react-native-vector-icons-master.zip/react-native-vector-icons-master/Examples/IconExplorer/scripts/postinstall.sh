#!/usr/bin/env bash

rm -rf node_modules/react-native-vector-icons/Examples
rm -rf node_modules/react-native-vector-icons/node_modules
