module.exports = {
  dependency: {
    assets: ['Fonts'],
  },
};
